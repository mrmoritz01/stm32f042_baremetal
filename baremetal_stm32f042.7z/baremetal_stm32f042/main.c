#include <stdint.h>
#include "stm32f0xx.h"

typedef void func(void);

func* p_fun;

#define P_FUN_ADD 0x10000004

int main(void)
{
	
	p_fun = (func*)(*(volatile uint32_t*)(P_FUN_ADD));
	
	p_fun();
	
	    //
    // Enable the GPIO pin for the 433MHz sender (PA4).  Set the direction as output, and
    // enable the GPIO pin for digital function.
    //
    RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
 
    GPIOA->MODER   |= (0x01U << (2*PIN_TX433));
    GPIOA->OSPEEDR |= (0x01U << (2*PIN_TX433));
 
    GPIOA->MODER   |= (0x01U << (2*6));
    GPIOA->OSPEEDR |= (0x01U << (2*6));
     
    GPIOA->BSRR = ((1U<<6)<<0);
	
	return 0;
}